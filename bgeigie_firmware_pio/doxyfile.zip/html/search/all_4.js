var searchData=
[
  ['data_53',['data',['../class_g_p_s_sensor.html#ab83d879aa5eb083da981d09c7e6d63b0',1,'GPSSensor::data()'],['../class_g_p_s_sensor.html#acb3432a71bf997a5a305b0238859042c',1,'GPSSensor::data() const']]],
  ['date_54',['date',['../class_tiny_g_p_s_plus.html#a83a70812b432d7f51c7c735bfe7be0f0',1,'TinyGPSPlus']]],
  ['day_55',['day',['../struct_tiny_g_p_s_date.html#ae8cc5f80c49e328f792d168a44062000',1,'TinyGPSDate']]],
  ['deg_56',['deg',['../struct_raw_degrees.html#a11831d9220f303bd716d9412af28e84e',1,'RawDegrees::deg()'],['../struct_tiny_g_p_s_course.html#a76dc8ae6c2fe5ead9b44c8d53a3272ca',1,'TinyGPSCourse::deg()']]],
  ['device_5fheader_57',['DEVICE_HEADER',['../config_8hpp.html#a13b51bdb19001339023a073629d0d18e',1,'config.hpp']]],
  ['device_5fid_58',['device_id',['../struct_display_data.html#a18f85013bc2db1d5db55d87eded63633',1,'DisplayData::device_id()'],['../struct_config_data.html#af4aa84fbef118fd20be9a243b4f1668f',1,'ConfigData::device_id()']]],
  ['device_5fnickname_59',['device_nickname',['../config_8hpp.html#a5f8b2d16c907ca3ebbc69f0f4491ab8a',1,'config.hpp']]],
  ['device_5fsetup_60',['device_setup',['../class_context.html#a54e51afce0edd534d7f0950ad83986ec',1,'Context']]],
  ['device_5fstarted_61',['DEVICE_STARTED',['../fsm__state__base_8hpp.html#a5667b805d857c6d28f83f6038a0272d3a04d407ea661493959d1c331f98bed756',1,'fsm_state_base.hpp']]],
  ['display_62',['Display',['../class_display.html',1,'Display'],['../class_context.html#a9921e196f07be3a73b723f68f140b988',1,'Context::display()'],['../class_display.html#a68ea14e4cecbdbce79dab91ac9154d9e',1,'Display::Display()']]],
  ['display_2ecpp_63',['display.cpp',['../display_8cpp.html',1,'']]],
  ['display_2ehpp_64',['display.hpp',['../display_8hpp.html',1,'']]],
  ['displaydata_65',['DisplayData',['../struct_display_data.html',1,'']]],
  ['displaystate_66',['DisplayState',['../display_8hpp.html#afbb0b74e0b5bea861360407d10426e7c',1,'display.hpp']]],
  ['distancebetween_67',['distanceBetween',['../class_tiny_g_p_s_plus.html#ace607cf3a6d49628e44eae1232237138',1,'TinyGPSPlus']]],
  ['dose_68',['dose',['../class_setup.html#a5a03eaf0e161266e37f48cc3fedf005d',1,'Setup']]],
  ['dosedata_69',['DoseData',['../struct_dose_data.html',1,'']]],
  ['draw_5fbase_70',['draw_base',['../class_display.html#aa64573075ec3f5141cb7906c9cbb4ad1',1,'Display']]],
  ['draw_5fmain_71',['draw_main',['../class_display.html#a67f2a955b6ece55b0523c08cac84653e',1,'Display']]],
  ['draw_5fnavbar_72',['draw_navbar',['../class_display.html#a75180c9b967a0126ce3b01a7ce6623b5',1,'Display']]],
  ['draw_5fqrcode_73',['draw_qrcode',['../class_display.html#aadce78ab84e53b437eedf6cc2d941a3a',1,'Display']]]
];
