var searchData=
[
  ['rawdegrees_358',['RawDegrees',['../struct_raw_degrees.html',1,'']]]
];
