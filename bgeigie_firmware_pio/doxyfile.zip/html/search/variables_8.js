var searchData=
[
  ['major_629',['MAJOR',['../config_8hpp.html#ab976d08f8762ed4298848ae330237a90',1,'config.hpp']]],
  ['minor_630',['MINOR',['../config_8hpp.html#ab28fb130c702bd359f772132957f38f3',1,'config.hpp']]],
  ['mode_631',['mode',['../struct_config_data.html#a463f5b14cb1e9aac840fd0a0e3ddc320',1,'ConfigData']]]
];
