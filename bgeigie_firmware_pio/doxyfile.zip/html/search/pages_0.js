var searchData=
[
  ['bgeigie_2dzen_20firmware_20_28esp32_29_729',['bGeigie-Zen firmware (ESP32)',['../md__r_e_a_d_m_e.html',1,'']]]
];
