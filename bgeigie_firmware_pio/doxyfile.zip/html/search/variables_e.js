var searchData=
[
  ['user_5fname_663',['user_name',['../struct_config_data.html#a4c9acea566e874ce9a24e555406a7ece',1,'ConfigData']]]
];
