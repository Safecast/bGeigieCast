var searchData=
[
  ['qr_5fcode_5fdev_5fid_5fndigits_634',['QR_CODE_DEV_ID_NDIGITS',['../config_8hpp.html#a19f748654b4acf1e8460dd5537c05abd',1,'config.hpp']]],
  ['qr_5fcode_5furl_5fbase_635',['QR_CODE_URL_BASE',['../config_8hpp.html#abce19322f5c54bf596c47078d910f71e',1,'config.hpp']]]
];
