var searchData=
[
  ['patch_633',['PATCH',['../config_8hpp.html#aabe4b3e1826d9969ffdbce0a856bff5c',1,'config.hpp']]]
];
