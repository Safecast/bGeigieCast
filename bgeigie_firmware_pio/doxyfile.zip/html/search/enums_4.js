var searchData=
[
  ['sd_5ferror_5ft_670',['sd_error_t',['../sd__wrapper_8hpp.html#a2c11b271fd9ae607114102201c05c87d',1,'sd_wrapper.hpp']]],
  ['sensormode_671',['SensorMode',['../setup_8hpp.html#abc47929dd59afff19be8147ebe8fa684',1,'setup.hpp']]],
  ['sensorshield_672',['SensorShield',['../setup_8hpp.html#aec493692f04b8ad0615bc96bb222762a',1,'setup.hpp']]],
  ['sensortype_673',['SensorType',['../setup_8hpp.html#a213c434cb928c4ca22513e2302632435',1,'setup.hpp']]]
];
