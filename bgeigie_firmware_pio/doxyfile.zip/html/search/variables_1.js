var searchData=
[
  ['alarm_5flevel_580',['alarm_level',['../struct_config_data.html#a0926ea1423d747769c2c483cfe9e67d8',1,'ConfigData']]],
  ['altitude_581',['altitude',['../class_tiny_g_p_s_plus.html#a0b3451a4ee75e5880ffd88c3038eacf8',1,'TinyGPSPlus']]]
];
