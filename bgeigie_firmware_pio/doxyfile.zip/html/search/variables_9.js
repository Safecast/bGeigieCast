var searchData=
[
  ['negative_632',['negative',['../struct_raw_degrees.html#a39c31d2d0332155a4d2c975cec0a796f',1,'RawDegrees']]]
];
