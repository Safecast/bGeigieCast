var searchData=
[
  ['date_593',['date',['../class_tiny_g_p_s_plus.html#a83a70812b432d7f51c7c735bfe7be0f0',1,'TinyGPSPlus']]],
  ['deg_594',['deg',['../struct_raw_degrees.html#a11831d9220f303bd716d9412af28e84e',1,'RawDegrees']]],
  ['device_5fheader_595',['DEVICE_HEADER',['../config_8hpp.html#a13b51bdb19001339023a073629d0d18e',1,'config.hpp']]],
  ['device_5fid_596',['device_id',['../struct_display_data.html#a18f85013bc2db1d5db55d87eded63633',1,'DisplayData::device_id()'],['../struct_config_data.html#af4aa84fbef118fd20be9a243b4f1668f',1,'ConfigData::device_id()']]],
  ['device_5fnickname_597',['device_nickname',['../config_8hpp.html#a5f8b2d16c907ca3ebbc69f0f4491ab8a',1,'config.hpp']]],
  ['device_5fsetup_598',['device_setup',['../class_context.html#a54e51afce0edd534d7f0950ad83986ec',1,'Context']]],
  ['display_599',['display',['../class_context.html#a9921e196f07be3a73b723f68f140b988',1,'Context']]]
];
