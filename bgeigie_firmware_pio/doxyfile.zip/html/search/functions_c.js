var searchData=
[
  ['n_5fbins_500',['n_bins',['../class_geiger_counter.html#a691c9d8c265c49ba7f5e494639eee6fa',1,'GeigerCounter']]],
  ['never_5ffixed_501',['never_fixed',['../class_g_p_s_sensor.html#a9dea482f3a1214e3fc5b0556edea84bf',1,'GPSSensor']]]
];
