var searchData=
[
  ['kilometers_484',['kilometers',['../struct_tiny_g_p_s_altitude.html#a1eb3e5b425784fc0db3e9ffe0f77f741',1,'TinyGPSAltitude']]],
  ['kmph_485',['kmph',['../struct_tiny_g_p_s_speed.html#a7fee3c8f9f2fcc5f4a517bd6108f79dd',1,'TinyGPSSpeed']]],
  ['knots_486',['knots',['../struct_tiny_g_p_s_speed.html#aa3a38ce4ece3d8062c794b73f260395e',1,'TinyGPSSpeed']]]
];
