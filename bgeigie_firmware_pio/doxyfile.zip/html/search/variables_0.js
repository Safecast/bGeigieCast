var searchData=
[
  ['_5fctx_579',['_ctx',['../class_state.html#a38a422deb0e859831f290bfd84956f01',1,'State']]]
];
