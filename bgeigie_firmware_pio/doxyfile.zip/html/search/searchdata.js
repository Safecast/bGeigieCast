var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvy",
  1: "bcdghrst",
  2: "bcdfghlmrst",
  3: "abcdefghiklmnoprstuvy",
  4: "_abcdghlmnpqstu",
  5: "degls",
  6: "dgls",
  7: "gst",
  8: "_c",
  9: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends",
  8: "Macros",
  9: "Pages"
};

