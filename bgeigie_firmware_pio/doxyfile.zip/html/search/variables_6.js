var searchData=
[
  ['hdop_621',['hdop',['../class_tiny_g_p_s_plus.html#a0bb6a7eb2d0261095911d71c8c067546',1,'TinyGPSPlus']]]
];
