var searchData=
[
  ['n_5fbins_206',['n_bins',['../class_geiger_counter.html#a691c9d8c265c49ba7f5e494639eee6fa',1,'GeigerCounter']]],
  ['negative_207',['negative',['../struct_raw_degrees.html#a39c31d2d0332155a4d2c975cec0a796f',1,'RawDegrees']]],
  ['never_5ffixed_208',['never_fixed',['../class_g_p_s_sensor.html#a9dea482f3a1214e3fc5b0556edea84bf',1,'GPSSensor']]]
];
