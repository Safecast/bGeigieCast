var searchData=
[
  ['logger_2ecpp_41',['logger.cpp',['../logger_8cpp.html',1,'']]]
];
