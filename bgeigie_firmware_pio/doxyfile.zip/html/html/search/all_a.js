var searchData=
[
  ['setup_30',['setup',['../main_8cpp.html#ad6ab2ba0b337de2f0ff6ae764a4ee18a',1,'main.cpp']]],
  ['setup_2ecpp_31',['setup.cpp',['../setup_8cpp.html',1,'']]]
];
